// Initialize Functions to Elements
document.getElementById('amountOfLeds').addEventListener('change', funcAdaptLEDLength);
document.getElementById('singleAnimationDropdown').addEventListener('change', funcAnimationMode);

/*-----------------------------------------------------------------------------
 * JavaSkript Function to Update LED Length Value to ESP8266
 * ----------------------------------------------------------------------------
*/
function funcAdaptLEDLength(){
  var _amountOfLeds = document.getElementById('amountOfLeds').value;
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "/updateLEDLength", true)
  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhr.send("newLength=" + _amountOfLeds);

  generateMatrix(_amountOfLeds);
}

/*-----------------------------------------------------------------------------
 * JavaSkript Function to Update specific LED Assignment to EKET
 * ----------------------------------------------------------------------------
*/
function funcAdaptLEDAssignment(_LEDnumber, _LEDAssignment){
  var numberString = _LEDnumber.replace(/dropdown/, '');
  _data = "LedNr=" + String(numberString) + "&Assig=" + String(_LEDAssignment);

  var xhr = new XMLHttpRequest();
  xhr.open("POST", "/updateSpecLED", true)
  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhr.send(_data);

  console.log(_data);
}

/*-----------------------------------------------------------------------------
 * JavaSkript Function to Update Animation Mode to ESP8266
 * ----------------------------------------------------------------------------
*/
function funcAnimationMode(){
  var _AnimationMode = document.getElementById('singleAnimationDropdown').value;
  hidePopup(true)
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "/animationMode", true)
  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhr.send("animationModeChecked=" + _AnimationMode);
}

/*-----------------------------------------------------------------------------
 * JavaSkript Function to Update RGB single Values to ESP8266
 * ----------------------------------------------------------------------------
*/
function funcSingleRGBValues(_rgb){
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "/singleRGBcolor", true)
  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhr.send("RGBvalue=" + _rgb);
}

/*-----------------------------------------------------------------------------
 * JavaSkript Function to Update LED Brightness to ESP8266
 * ----------------------------------------------------------------------------
*/
function funcUpdateBrightness(_Brightness){
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "/brightness", true)
  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhr.send("Brightness=" + _Brightness);
}

/*-----------------------------------------------------------------------------
 * JavaSkript Function to Update Animation Speed to ESP8266
 * ----------------------------------------------------------------------------
*/
function funcUpdateSpeed(_Speed){
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "/updateSpeed", true)
  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhr.send("Speed=" + _Speed);
}

/*-----------------------------------------------------------------------------
 * JavaSkript Function to Setup Server Send Events Handler between Server <-> Client
 * ----------------------------------------------------------------------------
*/
if (!!window.EventSource) {
  var source = new EventSource('/events');
  source.retry = 5000;

  source.addEventListener('open', function(e) {
    console.log("[SSE] Events Connected");
  }, false);

  source.addEventListener('error', function(e) {
    if (e.target.readyState != EventSource.OPEN) {
      console.log("[SSE] Events Disconnected");
    }
  }, false);

  source.addEventListener('message', function(e) {
    console.log("[SSE] message recived: ", e.data);

    if (e.data.indexOf("Hi! ") !== -1){
      // Reference
      //"Hello! SingleColorMode=" + String(SingleMode ? "false" : "true") +
      // " r=" + String(r) + " g=" + String(g) + " b=" +  String(b) + 
      // " Brigthness=" + String(brigthness) +
      // " Length=" + String(length) +
      // " AnimationMode=" +String(step) +
      // " Speed=" + String(systemParameters.speed) +
      // " LedAssignment=" +CalculateStringArray(length);
      
      var startIndex = e.data.indexOf("SingleColorMode=") + "SingleColorMode=".length;
      var endIndex = e.data.indexOf(" r=");
      var singleColorMode = e.data.substring(startIndex, endIndex);
  
      startIndex = endIndex + " r=".length;
      endIndex = e.data.indexOf(" g=");
      var r = e.data.substring(startIndex, endIndex);

      startIndex = endIndex + " g=".length;
      endIndex = e.data.indexOf(" b=");
      var g = e.data.substring(startIndex, endIndex);

      startIndex = endIndex + " b=".length;
      endIndex = e.data.indexOf(" Brigthness=");
      var b = e.data.substring(startIndex, endIndex);

      startIndex = endIndex + " Brigthness=".length;
      endIndex = e.data.indexOf(" Length=");
      var Brigthness = e.data.substring(startIndex,endIndex);

      startIndex = endIndex + " Length=".length;
      endIndex = e.data.indexOf(" AnimationMode=");
      var _Length = e.data.substring(startIndex, endIndex);

      startIndex = endIndex + " AnimationMode=".length;
      endIndex = e.data.indexOf(" Speed=");
      var _AnimationMode = e.data.substring(startIndex,endIndex);

      startIndex = endIndex + " Speed=".length;
      endIndex = e.data.indexOf(" LedAssignment=");
      var _AnimationSpeed = e.data.substring(startIndex,endIndex);

      startIndex = endIndex + " LedAssignment=".length;
      var LedtoEketAssingment = e.data.substring(startIndex);
      var array = LedtoEketAssingment.split(',');

      // Wert des 'Abtastinterval'-Parameters in das HTML-Element mit der ID 'Abtastinterval' schreiben
      document.getElementById('redSlider').value = r;
      document.getElementById('greenSlider').value = g;
      document.getElementById('blueSlider').value = b;
    
      document.getElementById('redInput').value = r;
      document.getElementById('greenInput').value = g;
      document.getElementById('blueInput').value = b;

      document.getElementById('brightSlider').value = Brigthness;
      document.getElementById('brightInput').value = Brigthness;

      document.getElementById('speedSlider').value = _AnimationSpeed;
      document.getElementById('speedInput').value = _AnimationSpeed;

      // Wert des 'SaveMode'-Parameters in das HTML-Element mit der ID 'SpeicherMethode' schreiben
      if(singleColorMode === "true"){
        hidePopup(false);
      } else {
        showPopup(false);
      }

      document.getElementById('singleAnimationDropdown').value = _AnimationMode;
      document.getElementById('amountOfLeds').value = _Length;
      generateMatrix(_Length, array);
    };
  }, false);
}

/*-----------------------------------------------------------------------------
 * JavaSkript RGB showPopup Function
 * ----------------------------------------------------------------------------
*/
function showPopup(noUpdate) {
  const popup = document.getElementById('rgbPopup');
  popup.style.display = 'block';
  var button = document.getElementById("ShowRGBPopup");
  button.style.display = 'none';

  if(noUpdate){
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "/singleColor", true)
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("SingleColorMode=" + true);
  }
}

/*-----------------------------------------------------------------------------
 * JavaSkript RGB hidePopup Function
 * ----------------------------------------------------------------------------
*/
function hidePopup(noUpdate) {
  const popup = document.getElementById('rgbPopup');
  popup.style.display = 'none';
  var button = document.getElementById("ShowRGBPopup");
  button.style.display = 'block';

  if(noUpdate){
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "/singleColor", true)
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("SingleColorMode=" + false);
  }
}

/*-----------------------------------------------------------------------------
 * JavaSkript UpdateRGBCode Function
 * ----------------------------------------------------------------------------
*/
function updateRGBCode() {
  const redValue = document.getElementById('redSlider').value;
  const greenValue = document.getElementById('greenSlider').value;
  const blueValue = document.getElementById('blueSlider').value;

  document.getElementById('redInput').value = redValue;
  document.getElementById('greenInput').value = greenValue;
  document.getElementById('blueInput').value = blueValue;

  const rgbCode = `rgb(${redValue}, ${greenValue}, ${blueValue})`;
  document.getElementById('rgbValue').textContent = rgbCode;
  document.getElementById('colorCircle').style.backgroundColor = rgbCode;

  if(isSliderMoving){
    funcSingleRGBValues(rgbCode);
    isSliderMoving = false;
  }
}

/*-----------------------------------------------------------------------------
 * JavaSkript EventListener Slider RGB-Code Update Function
 * ----------------------------------------------------------------------------
*/
const sliders = document.querySelectorAll('.color-slider');
let isSliderMoving = false;
sliders.forEach(slider => {
	slider.addEventListener('input', updateRGBCode);
	slider.addEventListener('change', () => {
	isSliderMoving = true;
	updateRGBCode();});
});

/*-----------------------------------------------------------------------------
 * JavaSkript EventListener Update RGB-Code Function
 * ----------------------------------------------------------------------------
*/
// Event Listener for Input, to Update RGB Code
const inputs = document.querySelectorAll('.color-input');
inputs.forEach(input => {
  input.addEventListener('change', function () {
    const redValue = document.getElementById('redInput').value;
    const greenValue = document.getElementById('greenInput').value;
    const blueValue = document.getElementById('blueInput').value;

    document.getElementById('redSlider').value = redValue;
    document.getElementById('greenSlider').value = greenValue;
    document.getElementById('blueSlider').value = blueValue;

    isSliderMoving = true;
    updateRGBCode();
  });
});

/*-----------------------------------------------------------------------------
* JavaSkript update Brightness Function
* ----------------------------------------------------------------------------
*/
function updateBrightnes(){
  const bright = document.getElementById('brightSlider').value;

  document.getElementById('brightInput').value = bright;

  if(brightSliderMoving){
    funcUpdateBrightness(bright);
    brightSliderMoving = false;
  }
}

/*-----------------------------------------------------------------------------
 * JavaSkript EventListener Slider Brigthness Update Function
 * ----------------------------------------------------------------------------
*/
const brighters = document.querySelectorAll('.bright-slider');
let brightSliderMoving = false;
brighters.forEach(slider => {
  slider.addEventListener('input', updateBrightnes);
  slider.addEventListener('change', () => {
  brightSliderMoving = true;
  updateBrightnes()});
});

/*-----------------------------------------------------------------------------
 * JavaSkript EventListener Update Brigthness Function
 * ----------------------------------------------------------------------------
*/
// Event Listener for Input, to Update Brigthness
const brightInput = document.querySelectorAll('.bright-input');
brightInput.forEach(input => {
  input.addEventListener('change', function () {
    const bright = document.getElementById('brightInput').value;

    document.getElementById('brightSlider').value = bright;
    brightSliderMoving = true;
    updateBrightnes();
  });
});


/*-----------------------------------------------------------------------------
* JavaSkript update Speed Function
* ----------------------------------------------------------------------------
*/
function updateSpeed(){
  const speed = document.getElementById('speedSlider').value;

  document.getElementById('speedInput').value = speed;

  if(speedSliderMoving){
    funcUpdateSpeed(speed);
    speedSliderMoving = false;
  }
}

/*-----------------------------------------------------------------------------
 * JavaSkript EventListener Slider Speed Update Function
 * ----------------------------------------------------------------------------
*/
const speeds = document.querySelectorAll('.speed-slider');
let speedSliderMoving = false;
speeds.forEach(slider => {
  slider.addEventListener('input', updateSpeed);
  slider.addEventListener('change', () => {
  speedSliderMoving = true;
  updateSpeed()});
});

/*-----------------------------------------------------------------------------
 * JavaSkript EventListener Update Speed Function
 * ----------------------------------------------------------------------------
*/
// Event Listener for Input, to Update Speed
const speedInput = document.querySelectorAll('.speed-input');
speedInput.forEach(input => {
  input.addEventListener('change', function () {
    const speed = document.getElementById('speedInput').value;

    document.getElementById('speedSlider').value = speed;
    speedSliderMoving = true;
    updateSpeed();
  });
});

/*-----------------------------------------------------------------------------
 * JavaSkript: Custom Matrix by Size to assign LED's to Shelf's
 * ----------------------------------------------------------------------------
*/
function generateMatrix(matrixSize, arr) {
  // Get Matrix Element
  const matrixContainer = document.getElementById("matrixContainer");
  
  // Save arr Elements of previous defined matrixContainer (if exists)
  if (arr === undefined) {
    arr = [];
    const dropdowns = matrixContainer.querySelectorAll("select");
    const selectedValues = [];

    dropdowns.forEach((dropdown) => {
      arr.push(dropdown.value);
    });
  }

  // Delete Previous created matrix Container Elements
  matrixContainer.innerHTML = "";

  for (let i = 0; i < matrixSize; i++) {  
    // Creating Matrix Headers:
    const label = document.createElement("label");
    label.textContent = "LED Nr. " + (i + 1) + ":";

    // Create Dropdown Elements and Numbers
    const dropdown = document.createElement("select");
    dropdown.name = "dropdown" + i;

    // Adding Min/Max Dropdown Value between 0 and 254 -->> 255 is reserved by ESP8266
    for (let j = 0; j <= 254; j++) {
      const option = document.createElement("option");
      option.value = j;
      option.text = j;
      dropdown.appendChild(option);
    }

    // If Defined Array is shorter then the new one -->> Init with Counter Varible "i"
    if (arr && arr[i] !== undefined) {
      dropdown.value = arr[i];
    }else{
      dropdown.value = i;
    }

    // Füge einen Event-Listener hinzu, um Änderungen zu verfolgen
    dropdown.addEventListener("change", function (event) {
      const selectedValue = event.target.value;
      const dropdownID = event.target.name;
      funcAdaptLEDAssignment(dropdownID, selectedValue);
    });

    matrixContainer.appendChild(label);
    matrixContainer.appendChild(dropdown);
  }
}
